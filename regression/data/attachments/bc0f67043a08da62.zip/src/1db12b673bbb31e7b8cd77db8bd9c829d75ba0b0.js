// Generated from: features/todos.feature
import { test } from "../../src/fixtures/index.js";

test.describe('Todos', () => {

  test('Adding a todo shows it in the list', { tag: ['@smoke'] }, async ({ Given, When, Then, todoPage }) => { 
    await Given('the todo app is open', null, { todoPage }); 
    await When('the user adds a todo "Buy milk"', null, { todoPage }); 
    await Then('the todo "Buy milk" is shown', null, { todoPage }); 
  });

  test('Completing a todo marks it done', async ({ Given, When, Then, todoPage }) => { 
    await Given('the todo "Walk the dog" is in the list', null, { todoPage }); 
    await When('the user completes the todo "Walk the dog"', null, { todoPage }); 
    await Then('the todo "Walk the dog" is completed', null, { todoPage }); 
  });

  test('The list starts empty', { tag: ['@smoke'] }, async ({ When, Then, todoPage }) => { 
    await When('the user opens the todo app', null, { todoPage }); 
    await Then('no todos are shown', null, { todoPage }); 
  });

  test('A missing todo shows failure evidence', { tag: ['@smoke'] }, async ({ Given, When, Then, todoPage }) => { 
    await Given('the todo app is open', null, { todoPage }); 
    await When('the scenario log is written', null, { todoPage }); 
    await Then('the todo "This todo was never added" is shown', null, { todoPage }); 
  });

});

// == technical section ==

test.use({
  $test: [({}, use) => use(test), { scope: 'test', box: true }],
  $uri: [({}, use) => use('features/todos.feature'), { scope: 'test', box: true }],
  $bddFileData: [({}, use) => use(bddFileData), { scope: "test", box: true }],
});

const bddFileData = [ // bdd-data-start
  {"pwTestLine":6,"pickleLine":4,"tags":["@smoke"],"steps":[{"pwStepLine":7,"gherkinStepLine":5,"keywordType":"Context","textWithKeyword":"Given the todo app is open","stepMatchArguments":[]},{"pwStepLine":8,"gherkinStepLine":6,"keywordType":"Action","textWithKeyword":"When the user adds a todo \"Buy milk\"","stepMatchArguments":[{"group":{"start":21,"value":"\"Buy milk\"","children":[{"start":22,"value":"Buy milk","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":9,"gherkinStepLine":7,"keywordType":"Outcome","textWithKeyword":"Then the todo \"Buy milk\" is shown","stepMatchArguments":[{"group":{"start":9,"value":"\"Buy milk\"","children":[{"start":10,"value":"Buy milk","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":12,"pickleLine":9,"tags":[],"steps":[{"pwStepLine":13,"gherkinStepLine":10,"keywordType":"Context","textWithKeyword":"Given the todo \"Walk the dog\" is in the list","stepMatchArguments":[{"group":{"start":9,"value":"\"Walk the dog\"","children":[{"start":10,"value":"Walk the dog","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":14,"gherkinStepLine":11,"keywordType":"Action","textWithKeyword":"When the user completes the todo \"Walk the dog\"","stepMatchArguments":[{"group":{"start":28,"value":"\"Walk the dog\"","children":[{"start":29,"value":"Walk the dog","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]},{"pwStepLine":15,"gherkinStepLine":12,"keywordType":"Outcome","textWithKeyword":"Then the todo \"Walk the dog\" is completed","stepMatchArguments":[{"group":{"start":9,"value":"\"Walk the dog\"","children":[{"start":10,"value":"Walk the dog","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
  {"pwTestLine":18,"pickleLine":15,"tags":["@smoke"],"steps":[{"pwStepLine":19,"gherkinStepLine":16,"keywordType":"Action","textWithKeyword":"When the user opens the todo app","stepMatchArguments":[]},{"pwStepLine":20,"gherkinStepLine":17,"keywordType":"Outcome","textWithKeyword":"Then no todos are shown","stepMatchArguments":[]}]},
  {"pwTestLine":23,"pickleLine":20,"tags":["@smoke"],"steps":[{"pwStepLine":24,"gherkinStepLine":21,"keywordType":"Context","textWithKeyword":"Given the todo app is open","stepMatchArguments":[]},{"pwStepLine":25,"gherkinStepLine":22,"keywordType":"Action","textWithKeyword":"When the scenario log is written","stepMatchArguments":[]},{"pwStepLine":26,"gherkinStepLine":23,"keywordType":"Outcome","textWithKeyword":"Then the todo \"This todo was never added\" is shown","stepMatchArguments":[{"group":{"start":9,"value":"\"This todo was never added\"","children":[{"start":10,"value":"This todo was never added","children":[{}]},{"children":[{}]}]},"parameterTypeName":"string"}]}]},
]; // bdd-data-end